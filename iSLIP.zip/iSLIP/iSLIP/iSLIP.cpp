// iSLIP.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include<iostream>
#include<conio.h>
#include<vector>
#include<map>
#include<algorithm>

using namespace std;

void Request(map<int,vector<int>> &output,map<int,vector<int>> &mp)
{
	for(auto it=output.begin();it!=output.end();it++)
	{
		int size=it->second.size();

		for(int i=0;i<size;i++)
			mp[i].push_back(it->first);
	}
}

void Grant(map<int,vector<int>> &mp,map<int,vector<int>> &output)
{
	map<int,vector<int>>::iterator it;
	int i,size,ip,op;

	for(it=mp.begin();it!=mp.end();it++)
	{
		ip=it->first;

		size=it->second.size();

		for(i=0;i<size;i++)
			output[it->second[i]].push_back(ip);
	}

	for(it=output.begin();it!=output.end();it++)
	{
		op=it->first;
		size=it->second.size();
		cout<<op<<" : ";
		for(i=0;i<size;i++)
			cout<<it->second[i]<<" ";
		cout<<endl;
	}
}

void Accept(map<int,vector<int>> &output,map<int,int> &input)
{
	map<int,vector<int>>::iterator it;
	
	int op,ip;

	for(it=output.begin();it!=output.end();it++)
	{
		op=it->first;
		ip=it->second[0];

		if(input.find(ip)==input.end()) //not in map
			input[ip]=op;
	}

	map<int,int>::iterator itr;

	for(itr=input.begin();itr!=input.end();itr++)
	{
		cout<<itr->first<<" : "<<itr->second<<endl;
	}

}

void Update_MP(map<int,vector<int>> &mp,map<int,int> &input,map<int,vector<int>> &output)
{
	//map<int,int>::iterator it;
	int ip,op;

	for(auto it=input.begin();it!=input.end();it++)
	{
		ip=it->first;
		op=it->second;
		//vector<int>::iterator itr;

		for(auto itr=mp[ip].begin();itr!=mp[ip].end();itr++)
		{
				if(*itr==op)
				{
					mp[ip].erase(itr);
					break;
				}
		}
		
	}

	for(auto it=mp.begin();it!=mp.end();it++)
	{
		ip=it->first;
		int size=it->second.size();
		cout<<ip<<" : ";
		for(int i=0;i<size;i++)
			cout<<it->second[i]<<" ";
		cout<<endl;
	}

}

void Update_OP(map<int,vector<int>> &output,map<int,int> &input)
{
	for(auto it=input.begin();it!=input.end();it++)
	{
		output[it->second].clear();
	}

	int ip;

	for(auto it=input.begin();it!=input.end();it++)
	{
		ip=it->first;

		for(auto itr=output.begin();itr!=output.end();itr++)
		{
			if(itr->second.size()==0) continue;
			for(auto i=itr->second.begin();i!=itr->second.end();i++)
			{
				if(*i==ip)
					{
						itr->second.erase(i,i+1);
						break;
		     		}
			}
		}
	}
}

int _tmain(int argc, _TCHAR* argv[])
{
	int i,j,n=3,ar[4],x,size;
	map<int,vector<int>> mp;


	for(i=1;i<=n;i++)
	{
		cin>>ar[i]; //no. of outputs for input port i
		for(j=0;j<ar[i];j++)
		{
			cin>>x;
			mp[i].push_back(x);
		}
		sort(mp[i].begin(),mp[i].end());
	}

	int count=2;
	map<int,vector<int>> output_copy;

	while(count--){

		map<int,int> input;
	    map<int,vector<int>> output;
		map<int,vector<int>> mp_round;
		if(count==1) 
			mp_round=mp;
		else Request(mp_round,output_copy);
		
		Grant(mp_round,output);
		Accept(output,input);
		//The remaining input ports will be checking for the remaining output ports
		Update_OP(output,input);
		output_copy=output;
	}
	//Update_MP(mp,input,output);
    
	
    getch();
	return 0;
}

/*3
1 2 3
3
1 2 3
3
1 3 4*/

//#include"stdafx.h"
#include<iostream>
#include<queue>
#include<conio.h>
#include<map>
#include<time.h>
#include<math.h>

using namespace std;

//setting default values
int N=12;                //no. of input and output ports
int B=8;                //buffer size
float p=0.5;                          //packet generation probability
string q_type="KOUQ";            //inq/kouq/islip
float K=-1;               
string output_file="output.txt";       //output filename
int T=10000;                      //maxtimeslots
float avg_packet_delay_iSLIP=0.0;
int packets_iSLIP=0;

//defining structure of a packet
struct packet{
	int inp;                  //inport port no.
	int op;                   //output port no.
	float start_time;         //start time of the packet
	int slot_time;            //slot n which it is generated
	int completion_time;      //completion time of the packet transmission
};

vector< queue <packet> > v_in;  //vector of queue for input ports
vector< queue <packet> > v_out;  //vector of queue for output ports
vector<vector<int> > contention;
vector <float> std_dev;
float total_delay=0.0;
float avg_packet_delay=0;
float sd_inq=0.0;

//function to generate probablities for inport port.
float gen_rand_prob(){
	return (float) rand() / RAND_MAX ;
}

//function to generate o/p port
float gen_op(int n){
	return  rand() % n ;
}

//function to generate start time of packets
float gen_st(){
	return  ((rand() % 10) + 1)/1000.0;
}

float calculateSD(){
    float sum = 0.0, mean, standardDeviation = 0.0;

    int i;

    for(i = 0; i < std_dev.size(); ++i)
    {
        sum += std_dev[i];
    }

    mean = sum/std_dev.size();

    for(i = 0; i < std_dev.size(); ++i)
        standardDeviation += pow(std_dev[i] - mean, 2.0);

    return sqrt(standardDeviation / std_dev.size());
}


//Grant phase
vector<int> Grant(map<int,vector<int>> mp,vector<pair<int,queue<int>>> oq,int N,vector<int> &served,vector<int> accept_arr)
{
	map<int,vector<int>> out;
	int input,i,output,size,flag;

	for(auto itr=mp.begin();itr!=mp.end();itr++)
	{
		input=itr->first;
		if(accept_arr[input]!=-1) continue;
		//cout<<input<<" : ";
		for(i=0;i<N;i++)
		{
			//cout<<itr->second[i]<<" ";
			if(itr->second[i]) // itr->second[i] says that if it is 1 then output port i is requested by input port 'input'
				out[i].push_back(input);  //Storing which input port requests into corresponding output port 
		}
		//cout<<endl;
	}

	//Now check which output ports grant which input port requests
	vector<int> grant_arr;

	for(i=0;i<N;i++)
		grant_arr.push_back(-1);

	for(auto itr=out.begin();itr!=out.end();itr++) //For each output port
	{
		output=itr->first;
		flag=0; //if output port grants any request from input port
		size=itr->second.size();
		if(served[output]==1) continue;
		for(i=0;i<size;i++)
		{
			if(oq[output].first==itr->second[i]) // oq[output].first contains the pointer position 
			//if g pointer points towards input port that requests this particular output port
				{
					grant_arr[output]=oq[output].first; //input port 'oq[output].first' granted by output port 'output'
					flag=1;
					break;
			  }
		}

		if(flag==0 && size>0) //output port didn't grant ANY request as the g pointer wasn't pointed to any input ports that requested
		{
			oq[output].first=itr->second[0]; //Move the g pointer to the 1st input port which requested it
			grant_arr[output]=oq[output].first; 
		}
	}

	return grant_arr;
}


void Accept(map<int,vector<int>> &mp,vector<int> grant_arr,int N,vector<pair<int,queue<int>>> &iq,vector<pair<int,queue<int>>> &oq,vector<int> &served,vector<int> &accept_arr,int curr_time)
{
	int i,ptr,output_ptr,ip;

	for(i=0;i<N;i++)
	{
		ip=grant_arr[i]; //output port i granted grant_arr[i]
		if(ip==-1 || accept_arr[ip]!=-1) //if this input port has already accepted
			continue;
	  //Now check if ip accepts it or not

		if(iq[ip].first== i && served[i]!=1) //if the 'a' pointer of input ip points towards output port i and i has not served anyone yet
		{
			accept_arr[ip]=i; //input ip accepts output i
			iq[ip].first=(i+1)%N; //Advancing pointer a
			output_ptr=oq[i].first;
			oq[i].first=(output_ptr+1)%N; //Advancing pointer g
			served[i]=1; //output port i serves some input port
			mp[ip][i]--; //1 less request to output port i
			struct packet tmp=v_in[ip].front();
			v_in[ip].pop(); //Popping from the input queue
			avg_packet_delay_iSLIP+=curr_time-tmp.start_time;
			std_dev.push_back(curr_time-tmp.start_time);
			packets_iSLIP++;
		}

		if(accept_arr[ip]==-1 && served[i]!=1) //ip doesn't accept any output port because the pointer doesn't point to the 
			                  // output which grants it and thereby remains un-served by output port i
							  //we can accept this grant and move the pointer accordingly
							  //pretend as if the a pointer was pointing at the output port
		{
			accept_arr[ip]=i;
			iq[ip].first=(i+1)%N;
			output_ptr=oq[i].first;
			oq[i].first=(output_ptr+1)%N;
			served[i]=1;
			mp[ip][i]--;
			struct packet tmp=v_in[ip].front();
			v_in[ip].pop(); //Popping from the input queue
			avg_packet_delay_iSLIP+=curr_time-tmp.start_time;
			std_dev.push_back(curr_time-tmp.start_time);
			packets_iSLIP++;
		}

	}
}


int main()
{
	int i,op,j;
	//cin>>N; //no. of input or output ports
	//N=4;
	//Making 2*N circular queues for 2*N ports to implement RR scheduling
	vector<pair<int,queue<int>>> iq; //making a vector of queues for N input ports each containing an accept pointer
	vector<pair<int,queue<int>>> oq; //making a vector of queues for N output ports each containing a grant pointer

	
	map<int,vector<int>> mp; //This contains the requests from each input port 

	for(i=0;i<N;i++) //For each input port
	{
		for(j=0;j<N;j++) //Initializing the N queue elements with 0
		{
			mp[i].push_back(0); //mp[i][j]=0 means input port i doesn't request for output port j while 1 means the opposite
		}
	}

	//Initializing the circular queues of each input port

	for(i=0;i<N;i++) //for each input port
	{
		queue<int> q;
		int ptr=0; //accept pointer position
		for(j=0;j<N;j++) // for each of the N elements in the queue
		{
			q.push(j);
		}

		//The q contains N elements from 0 to (N-1) corresponding to each of the output ports

		iq.push_back(make_pair(ptr,q)); //iq is the vector containing queues of the input ports
	}

	//Initializing the circular queues of each output port

	for(i=0;i<N;i++) //for each output port
	{
		queue<int> q;
		int ptr=0; //grant pointer position
		for(j=0;j<N;j++) // for each of the N elements in the queue
		{
			q.push(j);
		}

		//The q contains N elements from 0 to (N-1) corresponding to each of the input ports

		oq.push_back(make_pair(ptr,q)); //oq is the vector containing queues of the output ports
	}

	vector<int> served; //For each ROUND
    for(i=0;i<N;i++)
		served.push_back(0); //served[i]=1 means output port i has been accepted and else not
    vector<int> accept_arr; //For each ROUND
	for(i=0;i<N;i++)
		accept_arr.push_back(-1); //input port i accepts grant from output port. Initialized to -1
	vector<int> grant_arr;

	//-------------------------------------traffic generation----------------------------------//
		//declaring variables
		int curr_time=0;
	    float prob;
	    srand((unsigned) time(0));
	    int no_of_packets_gen=0;
	    int in_selected;
	    float pack_delay=0;

	    //initializing data structures
	    for(int i=0;i<N;i++){
	    	queue<packet> q;
	    	vector<int> v;                   //queue for each port
	    	v_in.push_back(q);               //making vector of queues
	    	contention.push_back(v);
	    	v_out.push_back(q);
	    }
	    
	    while(curr_time<T){   
			//for T timeslot
		//	cout<<"Round No. " <<curr_time<<endl;
		    for(int ip=0;ip<N;ip++){            //for all input ports
		    	
		    	prob=gen_rand_prob();
		    	if(prob<=p && v_in[ip].size()<B){
		    		no_of_packets_gen++;
		    		struct packet pack;                 //creating instance of a packet
		    		pack.inp=ip;
		    		pack.op=gen_op(N);
		    		pack.start_time=curr_time +gen_st();
		            pack.slot_time=curr_time;
					v_in[ip].push(pack);                //push the packet in the input queue
		            struct packet front_pack=v_in[ip].front();
		    		mp[pack.inp][pack.op]++; //input port inp requests for output port op
				}
	
		    }

//-----------------------------------iSLIP Scheduling------------------------------------------------------------
	
	
	int itr=0;
	
	while(itr<N)
	{
		grant_arr=Grant(mp,oq,N,served,accept_arr);
		//cout<<"Iteration "<<itr+1<<endl;
		Accept(mp,grant_arr,N,iq,oq,served,accept_arr,curr_time+1);
		/*for(i=0;i<N;i++)
			cout<<"Input port "<<i<<" accepts "<<accept_arr[i]<<endl;*/
        itr++;
	//	cout<<endl;
	}

	//Resetting for next round
	for(i=0;i<N;i++)
		served[i]=0; //served[i]=1 means output port i has been accepted and else not
	
	for(i=0;i<N;i++)
		accept_arr[i]=-1; //input port i accepts grant from output port. Initialized to -1

	curr_time++;
	}

		avg_packet_delay_iSLIP/=packets_iSLIP;
		float link_uti=(float)(packets_iSLIP)/(N*T);
		float sd_inq=calculateSD();
		
		cout<<"N\t"<<"p\t"<<"Queue type\t"<<"Avg PD\t"<<"       Std Dev of PD\t"<<"     Avg Link utilization"<<endl;
	    cout<<N<<"\t"<<p<<"\t"<<"iSLIP"<<"     \t"<<avg_packet_delay_iSLIP<<"  \t"<<sd_inq<<"  \t"<<link_uti<<endl;

	getch();

}
